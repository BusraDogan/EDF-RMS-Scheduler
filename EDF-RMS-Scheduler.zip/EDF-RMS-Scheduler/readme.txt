This project is  EDF & RMS Scheduler Program for Software Development with the Real-Time systems . 
You can easily understand and compare Earliest Deadline First and Rate-Monotonic Algorithms' performance with this program.

To run project;
Open project your IDE and run the project.
When the ınterface opened on your desktop you can enter any input values that you want.
Now you can see the scheduling results and graphics for the EDF and RMS.

For the follow logs run the below command;
-java -jar