
import java.util.ArrayList;
import java.util.LinkedList;

public class RMSImplementation {
	
	 private Task lastExecutedTask;
     private LinkedList<Task> queue=new LinkedList<>();
     private int timeLapsed;
	 private LinkedList<Task> periodicTaskList;
	 private int periodLCM;

	public RMSImplementation(LinkedList<Task> periodicTaskList) {
        this.periodLCM = Utils.calcLCM(periodicTaskList);
        this.periodicTaskList=periodicTaskList;
        checkInput();
    }
	
	private void checkInput() {
		 boolean isFailure;
         isFailure = !(Utils.sigma(periodicTaskList) <= (Utils.muSigma(periodicTaskList.size())));

         Utils.printSeperator();
         Utils.printWithAsterix("RMS START");
         if (isFailure) {
        	 Utils.printWithAsterix("##Note that this task set does not satisfy the schedulability check, ");
        	 Utils.printWithAsterix("therefore there are chances of deadline misses.");
         } else {
        	 Utils.printWithAsterix("##Note that this task set satisfies the schedulability check, ");
        	 Utils.printWithAsterix("therefore it is definitely schedulable by RMS.");
         }
         Utils.printAsterix();
	}
	
	public ScheduledTasks runRMS() {

		ScheduledTasks out = new ScheduledTasks();
		
		for (int i = 0;; i++) {
			// Add tasks to queue
			out.getDeadlinesList().add(i, new ArrayList<>());
			for (Task individualTask : periodicTaskList) {
				if (i % individualTask.getPeriod() == 0) {
					addNewTask(new Task(individualTask.getET(), individualTask.getPeriod(), individualTask.getId()));
				}
			}

			// Check cycle complete or not
			if (i != 0 && i % periodLCM == 0) {
				int tempVar = 0;
                 if (queue.size() == periodicTaskList.size()) {
                     for (int k = 0; k < queue.size(); k++) {
                         if (queue.get(k).getRemainingTime() != queue.get(k).getET()) {
                             tempVar = 1;
                             break;
                         }
                     }
                 }
				if (tempVar == 0) {
					Utils.printAsterix();
					Utils.printWithAsterix("End of one complete cycle");
					Utils.printAsterix();
					Utils.printWithAsterix("The RMS Execution Done ");
					Utils.printSeperator();
					return out;
				}
			}

			// Execute Once!
			ERMSExecute output = executeOneUnit(out);

			if (output.equals(ERMSExecute.NOTHING_TO_DO) || output.equals(ERMSExecute.DEADLINE_MISSED)) {
				out.getTaskList().add(null);
			}
		}
	}
   
   
    public ERMSExecute executeOneUnit(ScheduledTasks out) {
        if (queue.isEmpty()) {
            timeLapsed++;
            return ERMSExecute.NOTHING_TO_DO;
        }
        timeLapsed++;
        Task t = queue.getFirst();
        if (t.getRemainingTime() <= 0) {
            return ERMSExecute.ERROR;
        }
        
        t.setRemainingTime(t.getRemainingTime()-1);
        if ((t.getRemainingTime() + 1 == t.getET()) || (t != lastExecutedTask && lastExecutedTask != null)) {
        	Utils.printWithAsterixAlignl("At time " + (timeLapsed - 1) + ", T" + t.getId() + " has started execution.");
        }
        out.getTaskList().add(t);
        lastExecutedTask = t;
        if(queue.getFirst().getEntryTime() + queue.getFirst().getPeriod()==timeLapsed) {
    	 out.getDeadlinesList().get(timeLapsed-1).add(lastExecutedTask);
        }
        //After running if remaining time becomes zero, i.e. process is completely executed
        if (t.getRemainingTime() == 0) {
            if (t.getEntryTime() + t.getPeriod() >= timeLapsed) {
            	Utils.printWithAsterixAlignl("At time " + (timeLapsed) + ", T" + t.getId() + " has been completely executed.");
                queue.pollFirst();
                return ERMSExecute.PROCESS_COMPLETE;
            } else {
            	Utils.printWithAsterixAlignl("T" + queue.getFirst().getId() + " finished at time " + timeLapsed + " thus, missing it's deadline of time " + (queue.getFirst().getEntryTime() + queue.getFirst().getPeriod()) + ".");
            	queue.pollFirst();
                return ERMSExecute.DEADLINE_MISSED;
            }
        }
        
        return ERMSExecute.CONTINUE;

    }

    public ETask addNewTask(Task t) {
        if (queue.isEmpty()) {
            queue.addFirst(t);
            t.setEntryTime(timeLapsed);
            return ETask.EMPTY;
        }
        if (t.getPeriod() == queue.getFirst().getPeriod()) {
            queue.add(1, t);
            t.setEntryTime(timeLapsed) ;
            return ETask.IDENTICAL;
        }
        if (t.getPeriod() < queue.getFirst().getPeriod()) {
            boolean tFlag = queue.getFirst().getET() == queue.getFirst().getRemainingTime();
            queue.addFirst(t);
            t.setEntryTime(timeLapsed);
            if (tFlag) return ETask.NOT_PRE_EMPTED;
            else {
            	Utils.printWithAsterixAlignl("At time " + timeLapsed + ", T" + queue.get(1).getId() + " has been preempted.");
                return ETask.PRE_EMPTED;
            }
        }
        if (t.getPeriod() > queue.getFirst().getPeriod()) {
            if (queue.size() == 1) {
                queue.add(t);
                t.setEntryTime(timeLapsed);
                return ETask.LESS_PRIORITY;
            }
            for (int i = 1; i < queue.size(); i++) {
                if (t.getPeriod() < queue.get(i).getPeriod()) {
                    queue.add(i, t);
                    t.setEntryTime(timeLapsed);
                    return ETask.MIDDLE;
                }
                if (t.getPeriod() > queue.get(i).getPeriod() && i == queue.size() - 1) {
                        queue.add(t);
                        t.setEntryTime(timeLapsed);
                        return ETask.LEAST_PRIORITY;
                }
            }
        }
        return ETask.IMPOSSIBLE;
    }
}
