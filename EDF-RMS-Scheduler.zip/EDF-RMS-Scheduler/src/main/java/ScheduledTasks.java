

import java.util.ArrayList;
import java.util.List;

public class ScheduledTasks {

    private List<Task> taskList = new ArrayList<>();
    private List<List<Task>> deadlinesList = new ArrayList<>();

    public List<Task> getTaskList() {
        return taskList;
    }

    public List<List<Task>> getDeadlinesList() {
        return deadlinesList;
    }

    
}