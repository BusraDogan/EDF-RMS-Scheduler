

public enum ERMSExecute {

	NOTHING_TO_DO, //0 -> Nothing to do
	NORMAL, //1 -> Everything went normally
	DEADLINE_MISSED, //-1 -> Deadline Missed!
	PROCESS_COMPLETE,  //2 -> Process completely executed without missing the deadline
	CONTINUE,
	ERROR;
}
