

public enum ETask {

	EMPTY, //Added task in empty queue -> 0
	IDENTICAL, //Added identical task to the first task -> 1
	PRIORITIZED, //Added the most prioritized task
	NOT_PRE_EMPTED,//Previous Process Not Pre-Empted -> 2
	PRE_EMPTED,//Previous Process Pre-Empted -> 3
	LESS_PRIORITY, //Added the second task with less priority -> 4
	MIDDLE, //Added task somewhere in the middle -> 5
	LEAST_PRIORITY, //Added the least prioritized task in a list with size more than 2 -> 6
	IMPOSSIBLE;//Impossible -> 7
	 
   
   
    
    
   
   
   
    
}
