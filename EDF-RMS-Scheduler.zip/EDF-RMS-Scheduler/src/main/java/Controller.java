

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.SubScene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;


public class Controller {

    private ObservableList<Task> taskListEdf = FXCollections.observableArrayList();
    private ObservableList<Task> taskListRms = FXCollections.observableArrayList();

    private String[] style = {"status-one", "status-two", "status-three", "status-four", "status-five",
            "status-six", "status-seven", "status-eight", "status-nine", "status-ten", "status-eleven",
            "status-twelve"};
    private List<String> styleList;

    @FXML
    private TextField txtET;
    @FXML
    private TextField txtPeriod;
    @FXML
    private TableView<Task> taskTable;
    @FXML
    private TableColumn columnId;
    @FXML
    private TableColumn columnET;
    @FXML
    private TableColumn columnPeriod;
    @FXML
    private Label lblLCM;
    
    @FXML
    private TableView<TableItem> scheduleTableEdf;
    @FXML
    private TableView<TableItem> scheduleTableRms;
    @FXML
    private TableColumn columnTimeEdf;
    @FXML
    private TableColumn columnTaskEdf;
    @FXML
    private TableColumn columnDeadlinesEdf;
    @FXML
    private TableColumn columnDeadlinesRms;
    @FXML
    private TableColumn columnTimeRms;
    @FXML
    private TableColumn columnTaskRms;
    
    @FXML
    private SubScene chartSceneEdf;
    @FXML
    private SubScene chartSceneRms;

    

    @FXML
    private void addTask() {
    	if(txtET.getText()!=null && ! txtET.getText().isEmpty() && txtPeriod.getText()!=null && !txtPeriod.getText().isEmpty()) {
    		Task t = new Task(Integer.parseInt(txtET.getText()),Integer.parseInt(txtPeriod.getText()));
    		taskListEdf.add(t);
    		taskListRms.add(new Task(t.getET(),t.getPeriod(),t.getId()));
	        columnET.setCellValueFactory(new PropertyValueFactory<>("eT"));
	        columnPeriod.setCellValueFactory(new PropertyValueFactory<>("period"));
	        columnId.setCellValueFactory(new PropertyValueFactory<>("name"));

	        taskTable.setItems(taskListEdf);
	        txtET.setText("");
	        txtPeriod.setText("");
	        lblLCM.setText(Integer.toString(Utils.calcLCM(taskListEdf)));
    	}
       
    }
    @FXML
    private void clearTask() {
    	taskListEdf = FXCollections.observableArrayList();
        taskListRms = FXCollections.observableArrayList();
        txtET.setText("");
        txtPeriod.setText("");
        taskTable.setItems(null);
        lblLCM.setText("0");
        Task.resetCount();
        chartSceneEdf.setRoot(drawChartEdf(new ArrayList<Task>()));
        chartSceneRms.setRoot(drawChartRms(new ArrayList<Task>()));
        columnTimeEdf.setCellValueFactory(null);
        columnTaskEdf.setCellValueFactory(null);
        columnDeadlinesEdf.setCellValueFactory(null);
        scheduleTableEdf.setItems(null);
        columnTimeRms.setCellValueFactory(null);
        columnTaskRms.setCellValueFactory(null);
        scheduleTableRms.setItems(null);
    }
    @FXML
    private void exampleOne() {
    	txtET.setText("2");txtPeriod.setText("10");addTask();
    	txtET.setText("3");txtPeriod.setText("15");addTask();
    	txtET.setText("3");txtPeriod.setText("10");addTask();
    	txtET.setText("4");txtPeriod.setText("30");addTask();
    	
    }
    @FXML
    private void exampleTwo() {
    	txtET.setText("1");txtPeriod.setText("4");addTask();
    	txtET.setText("2");txtPeriod.setText("5");addTask();
    	txtET.setText("5");txtPeriod.setText("20");addTask();
    }
    @FXML
    private void exampleThree() {
    	txtET.setText("2");txtPeriod.setText("5");addTask();
    	txtET.setText("4");txtPeriod.setText("7");addTask();
    }
    @FXML
    private void exampleFour() {
    	txtET.setText("2");txtPeriod.setText("4");addTask();
    	txtET.setText("3");txtPeriod.setText("8");addTask();
    	txtET.setText("2");txtPeriod.setText("16");addTask();
    }
    @FXML
    private void exampleFive() {
    	txtET.setText("3");txtPeriod.setText("20");addTask();
    	txtET.setText("2");txtPeriod.setText("5");addTask();
    	txtET.setText("2");txtPeriod.setText("10");addTask();
    }
    @FXML
    private void exampleSix() {
    	txtET.setText("1");txtPeriod.setText("10");addTask();
    	txtET.setText("2");txtPeriod.setText("12");addTask();
    	txtET.setText("1");txtPeriod.setText("5");addTask();
    }
    
    @FXML
    private void schedule() {
    	if(taskListEdf!=null && !taskListEdf.isEmpty()) {
    	    styleList = new ArrayList<>(Arrays.asList(style));
            ScheduledTasks scheduledTasksEdf = Scheduler.scheduleEdf(taskListEdf);
            List<Task> scheduledTaskListEdf = new ArrayList<>(scheduledTasksEdf.getTaskList());
            List<List<Task>> deadlinesListEdf = new ArrayList<>(scheduledTasksEdf.getDeadlinesList());
            fillTableEdf(scheduledTaskListEdf, deadlinesListEdf);
            TimelineChart chartEdf = drawChartEdf(scheduledTaskListEdf);
            chartSceneEdf.setRoot(chartEdf);
            
            ScheduledTasks scheduledTasksRms = Scheduler.scheduleRms(taskListRms);
            List<Task> scheduledTaskListRms = new ArrayList<>(scheduledTasksRms.getTaskList());
            List<List<Task>> deadlinesListRms = new ArrayList<>(scheduledTasksRms.getDeadlinesList());
            fillTableRms(scheduledTaskListRms.subList(0, Integer.parseInt(lblLCM.getText())), deadlinesListRms.subList(0, Integer.parseInt(lblLCM.getText())));
            TimelineChart chartRms = drawChartRms(scheduledTaskListRms);
            chartSceneRms.setRoot(chartRms);
    	}
    }

    private TimelineChart drawChartEdf(List<Task> scheduledTaskList) {

        List<String> nameList = new ArrayList<>();
        for(Task t : taskListEdf)
            nameList.add(t.getName());

        NumberAxis xAxis = new NumberAxis();
        xAxis.setAutoRanging(false);
        xAxis.setMinorTickCount(5);
        xAxis.setLowerBound(0);
        xAxis.setUpperBound(Double.parseDouble(lblLCM.getText()));
        xAxis.setTickUnit(1);
        CategoryAxis yAxis = new CategoryAxis();
        yAxis.setTickLabelGap(10);
        yAxis.setAutoRanging(false);
        yAxis.setCategories(FXCollections.observableArrayList(nameList));

        TimelineChart chart = new TimelineChart(xAxis, yAxis);
        chart.setTitle("Earliest-Deadline First (EDF)");
        chart.setLegendVisible(false);

        ObservableList<XYChart.Series<Number, String>> chartData = FXCollections.observableArrayList();
        for(Task t : taskListEdf) {
            ObservableList<XYChart.Data<Number, String>> seriesData = FXCollections.observableArrayList();
            String styleClass =  styleList.get(t.getId()%12);
            for(int i = 0; i < scheduledTaskList.size(); i++) {
                if(t.equals(scheduledTaskList.get(i)))
                    seriesData.add(new XYChart.Data<>(i, t.getName(), new TimelineChart.ExtraData(styleClass)));
            }
            chartData.add(new XYChart.Series<>(seriesData));
        }
        chart.setData(chartData);
        chart.getStylesheets().add(getClass().getResource("timeline.css").toExternalForm());

        return chart;
    }
    private TimelineChart drawChartRms(List<Task> scheduledTaskList) {

        List<String> nameList = new ArrayList<>();
        for(Task t : taskListRms)
            nameList.add(t.getName());

        NumberAxis xAxis = new NumberAxis();
        xAxis.setAutoRanging(false);
        xAxis.setMinorTickCount(5);
        xAxis.setLowerBound(0);
        xAxis.setUpperBound(Double.parseDouble(lblLCM.getText()));
        xAxis.setTickUnit(1);
        CategoryAxis yAxis = new CategoryAxis();
        yAxis.setTickLabelGap(10);
        yAxis.setAutoRanging(false);
        yAxis.setCategories(FXCollections.observableArrayList(nameList));

        TimelineChart chart = new TimelineChart(xAxis, yAxis);
        chart.setTitle("Rate-monotonic (RM)");
        chart.setLegendVisible(false);

        ObservableList<XYChart.Series<Number, String>> chartData = FXCollections.observableArrayList();
        for(Task t : taskListRms) {
            ObservableList<XYChart.Data<Number, String>> seriesData = FXCollections.observableArrayList();
            String styleClass =styleList.get(t.getId()%12);
            for(int i = 0; i < scheduledTaskList.size(); i++) {
                if(scheduledTaskList.get(i)!=null && t.getName().equals(scheduledTaskList.get(i).getName()))
                    seriesData.add(new XYChart.Data<>(i, t.getName(), new TimelineChart.ExtraData(styleClass)));
            }
            chartData.add(new XYChart.Series<>(seriesData));
        }
        chart.setData(chartData);
        chart.getStylesheets().add(getClass().getResource("timeline.css").toExternalForm());

        return chart;
    }

    private void fillTableEdf(List<Task> scheduledTaskList, List<List<Task>> scheduledDeadlinesList) {

        ObservableList<TableItem> tableList = FXCollections.observableArrayList();
        for(int i = 0; i < scheduledTaskList.size(); i++)
            tableList.add(new TableItem(i, scheduledTaskList.get(i), scheduledDeadlinesList.get(i)));

        columnTimeEdf.setCellValueFactory(new PropertyValueFactory<>("time"));
        columnTaskEdf.setCellValueFactory(new PropertyValueFactory<>("task"));
        columnDeadlinesEdf.setCellValueFactory(new PropertyValueFactory<>("deadline"));
        scheduleTableEdf.setItems(tableList);

    }
    
    private void fillTableRms(List<Task> scheduledTaskList, List<List<Task>> scheduledDeadlinesList) {

        ObservableList<TableItem> tableList = FXCollections.observableArrayList();
        for(int i = 0; i < scheduledTaskList.size(); i++)
            tableList.add(new TableItem(i, scheduledTaskList.get(i), scheduledDeadlinesList.get(i)));

        columnTimeRms.setCellValueFactory(new PropertyValueFactory<>("time"));
        columnTaskRms.setCellValueFactory(new PropertyValueFactory<>("task"));
        columnDeadlinesRms.setCellValueFactory(new PropertyValueFactory<>("deadline"));
        scheduleTableRms.setItems(tableList);

    }

    private String getRandomStyle(int i) {
        String randomStyle = styleList.get(i);
        styleList.remove(i);
        return randomStyle;
    }

    public static class TableItem {

        private int time;
        private String task;
        private String deadline;

        public TableItem(int time, Task task, List<Task> deadline) {
            this.task = (task != null)? task.toString() : "idle";
            this.deadline = deadline.toString().replaceAll("[\\[\\]]", "");
            this.time = time;
        }

        public int getTime() {
            return time;
        }

        public String getTask() {
            return task;
        }

        public String getDeadline() {
            return deadline;
        }

        public void setTime(int time) {
            this.time = time;
        }

        public void setTask(String task) {
            this.task = task;
        }

        public void setDeadline(String deadline) {
            this.deadline = deadline;
        }
    }

}
