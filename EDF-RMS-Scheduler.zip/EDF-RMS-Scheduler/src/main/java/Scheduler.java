

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


public class Scheduler {

	public static ScheduledTasks scheduleEdf(final List<Task> taskList) {

        int lcm = Utils.calcLCM(taskList);
        ScheduledTasks out = new ScheduledTasks();
        Map<Integer, List<Task>> waitingMap = new HashMap<>();
        Utils.printSeperator();
        Utils.printWithAsterix("EDF START");
        Utils.printAsterix();

        for(int timeUnit = 0; timeUnit < lcm; timeUnit++) {

            out.getDeadlinesList().add(timeUnit, new ArrayList<>());

            //add iterative tasks into the waiting list
            for(Task t : taskList) {
            	if(timeUnit % t.getPeriod() == 0) {
                    if(! waitingMap.containsKey(timeUnit + t.getPeriod())) {
                    	waitingMap.put(timeUnit + t.getPeriod(), new ArrayList<>());
                    }
                    for(int i = 0; i < t.getET(); i++) {
                    	 waitingMap.get(timeUnit + t.getPeriod()).add(t);
                    }
                    out.getDeadlinesList().get(timeUnit).add(t);
                }
            }
                

            if(! waitingMap.isEmpty()) {
                //the highest priority task has the minimum period
                Integer minKey = waitingMap.keySet().stream().min(Integer::compareTo).get();
                Task t =waitingMap.get(minKey).get(0);
            	Utils.printWithAsterixAlignl("At time " + (timeUnit) + ", T" + t.getId() + " has started execution.");
                out.getTaskList().add(t);
                waitingMap.get(minKey).remove(0);
                if(waitingMap.get(minKey).isEmpty()) {
                	waitingMap.remove(minKey);
                	Utils.printWithAsterixAlignl("At time " + (timeUnit) + ", T" + t.getId() + " has been completely executed.");
                }
                    
            } else {
            	out.getTaskList().add(null);
            }
        }

        out.getDeadlinesList().remove(0);
        out.getDeadlinesList().add(new ArrayList<>());
        Utils.printWithAsterix("End of one complete cycle");
		Utils.printAsterix();
		Utils.printWithAsterix("The EDF Execution Done ");
        return out;
    }
    
    
    
    public static ScheduledTasks scheduleRms(List<Task> taskList) {
    	RMSImplementation rms = new RMSImplementation(new LinkedList<>(taskList));
        return rms.runRMS();
	}


   


   

}
