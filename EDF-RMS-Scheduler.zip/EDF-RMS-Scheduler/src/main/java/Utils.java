
import java.util.LinkedList;
import java.util.List;

public class Utils {
	private static final int LINE_LENGTH=85;

	public static int gcd(int a, int b) {
		while (b > 0) {
			int temp = b;
			b = a % b; // % is remainder
			a = temp;
		}
		return a;
	}


	 public static int calcLCM(List<Task> taskList) {

	        int lcm = taskList.get(0).getPeriod();
	        for(boolean flag = true; flag; ) {
	            for(Task x : taskList) {
	                if(lcm % x.getPeriod() != 0) {
	                    flag = true;
	                    break;
	                }
	                flag = false;
	            }
	            lcm = flag? (lcm + 1) : lcm;
	        }

	        return lcm;
	    }
	public static double sigma(LinkedList<Task> taskList) {
		double returnValue = 0.00;
		for (Task eachTask : taskList) {
			returnValue = returnValue + (((double) eachTask.getET()) / ((double) eachTask.getPeriod()));
		}
		return returnValue;
	}

	public static double muSigma(int n) {
		return ((double) n) * ((Math.pow((double) 2, ((1 / ((double) n)))) - (double) 1));
	}
	
	public static void printSeperator() {
		printAsterix();
		printAsterix();
	}
	
	public static void printAsterix() {
		String s ="";
		for (int i = 0; i <LINE_LENGTH; i++) {
			s=s+"*";
		}
		System.out.println(s);
	}
	
	public static void printWithAsterix(String s) {
		String leftAsterix="";
		String rightAsterix="";
		int count = (LINE_LENGTH-s.length()-10)/2;
		for (int i = 0; i <count; i++) {
			leftAsterix=leftAsterix+" ";
			rightAsterix=rightAsterix+" ";
		}
		System.out.println("***"+leftAsterix+"  "+s+"  "+rightAsterix+"***");
	}
	public static void printWithAsterixAlignl(String s) {
		String asterix="";
		int count = (LINE_LENGTH-s.length()-10);
		for (int i = 0; i <count; i++) {
			asterix=asterix+" ";
		}
		System.out.println("***"+"  "+s+"  "+asterix+"***");
	}
}
